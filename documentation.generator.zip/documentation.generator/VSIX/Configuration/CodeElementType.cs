﻿namespace Documentation.VSIX.Configuration
{
    public enum CodeElementType
    {
        Namespace,
        Delegate,
        Interface,
        Class,
        Struct,
        Record,
        Enum
    }
}
